<html>
<style>
	
	body{
	background-image:url('midd.jpg');
	background-attachment: fixed;
	background-size:cover;
	background-repeat:no-repeat;
	background-position: 90% 0%;
	font-family: 'Spinnaker', sans-serif; 
	font-weight: 400;
	color:#FFFFFF;
	
	}
	
	h2{ font-family: 'Megrim', cursive;
			font-weight: 400; 
			text-align:center; 
			font-size:60px;
			margin: 0px; }
	
	a:link {text-decoration:none; 
			color:#FFFFFF;}    /* unvisited link */
	a:visited {text-decoration:none; 
			color:#FFFFFF;} /* visited link */
	a:hover {text-decoration:none; 
			color:#0099FF;}   /* mouse over link */
	a:active {text-decoration:none; 
			color:#0099FF;}  /* selected link */
	
	div{text-align:center; 
				font-family: 'Megrim', cursive;
				font-weight: 500; 
				font-size:150%;}
		
	.quote {font-family: 'Spinnaker', sans-serif;
			text-align:center; 
			font-size:15px;
			color:#FFFFFF;
			}
	
	.subhead{text-align:center; 
			font-family: 'Spinnaker', sans-serif;
			font-size:100%;
			color:#FFFFFF;}
	
	.seeMoreDiv{text-align:center;
				}
	
	.event_title{ font-family: 'Spinnaker', sans-serif;
			color:#FFFFFF; 
			font-size:25px;}
			
	.event{	font-family: 'Spinnaker', sans-serif;
			color: #FFFFFF; 
			font-size:18px;}
	
	.search_key{color:#FFFFFF;
				display: inline-block;
				border-top-style:solid; 
				border-bottom-style:solid; 
				border-color:#FFFFFF; 
				font-size:30px;}
				
	.session_head{
				font-family: 'Spinnaker', sans-serif;
				color:#FFFFFF;
				text-align: right;
				font-size:15px;}
	
	p{font-size:150%; 
			color:#FFFFFF;
			text-decoration:underline;
			display: inline; }
	
	input{ font-weight: 400;
			display: inline;}
	
	
	.submitLink {font-family: 'Spinnaker', sans-serif;
			font-size: 15px;
			background-color: transparent;
			color:#FFFFFF;
			border: none;
			cursor: pointer;
			cursor: hand;}
			
	.submitLink:hover {text-decoration:none; 
			color:#0099FF;}
			
	.seeMore {font-family: 'Spinnaker', sans-serif;
			font-size: 15px;
			background-color: transparent;
			color:#FFFFFF;
			border: none;
			cursor: pointer;
			cursor: hand;}
			
	.seeMore:hover {text-decoration:none; 
			color:#0099FF;}
	
	
	
	
</style>
</html>
