#! /bin/sh
curl -o temp.txt http://www.cs.middlebury.edu/~gkrathwohl/middCalendar/addRSSevents.php



